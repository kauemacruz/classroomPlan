﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestClassroom
{

    [TestClass]
    public class UnitTest1
    {
        //string array with classroom data
        string[] classData = ClassroomPlan.Methods.GetData("@classroomData");

        /// <summary>
        /// Method: AreSame
        /// Purpose: check if both number are equal
        /// Input: void
        /// Output: void
        /// </summary>
        public bool AreSame(int list1, int list2)
        {
            bool result = true;

            if (list1 == list2)
            {
                result = true;

            }
            else
            {
                result = false;
            }
            return result;
        }
        /// <summary>
        /// Method: indexFound
        /// Purpose: if index is bigger than or equal to zero it means that index exists 
        /// Input: void
        /// Output: void
        /// </summary>
        public bool IndexFound(int index)
        {
            bool result = true;

            if (index >= 0)
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

        /// <summary>
        /// Method: TestMethod1
        /// Purpose: add new student to list imported from external file and checks if an extra element was added to list
        /// Input: void
        /// Output: void
        /// </summary>
        [TestMethod]
        public void TestMethod1()
        {
            List<ClassroomPlan.Student> studentList = ClassroomPlan.Methods.getStudentList(classData);
            List<string> studentNames = ClassroomPlan.Methods.getStudentNameList(classData);

            int listBeforeNew = studentList.Count + 1;

            ClassroomPlan.Methods.editCellValue("", "Kaue", 4, 14, studentList, studentNames);
            int listAfterNew = studentList.Count;

            bool expectedResult = true;
            bool actualResult = AreSame(listBeforeNew, listAfterNew);
            Assert.AreEqual(expectedResult, actualResult);
        }

        /// <summary>
        /// Method: TestMethod2
        /// Purpose: adds new element to imported list from external file and checks if element was actually added to list
        /// Input: void
        /// Output: void
        /// </summary>

        [TestMethod]
        public void TestMethod2()
        {
            List<ClassroomPlan.Student> studentList = ClassroomPlan.Methods.getStudentList(classData);
            List<string> studentNames = ClassroomPlan.Methods.getStudentNameList(classData);

            ClassroomPlan.Methods.editCellValue("", "Kaue", 4, 14, studentList, studentNames);

            int foundIndex = ClassroomPlan.Methods.BinarySearch("Kaue", studentNames);

            bool expectedResult = true;
            bool actualResult = IndexFound(foundIndex);
            Assert.AreEqual(expectedResult, actualResult);
        }
    }
}
