﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClassroomPlan
{
    /// <summary>
    /// Class: Methods
    /// Purpose: Class created to handle all methods of application
    /// </summary>
    public class Methods
    {
        /// <summary>
        /// Method: GetData
        /// Purpose: Gets data of external file and returns data
        /// Input: string filepath
        /// Output: string[] lines
        /// </summary>
        public static string[] GetData(string filepath)
        {
            //empty string[] that will be returned with values after data is imported from external file
            string[] lines = { };
            
            try
            {
                if (File.Exists(filepath))
                {
                    using (StreamReader sr = new StreamReader(filepath))
                    {
                        string line = "";


                        while ((line = sr.ReadLine()) != null)
                        {
                            //string[] is populated with all lines of external file, each line is one string in the array
                            lines = File.ReadAllLines(filepath);
                        }
                        
                    }
                }
            }
            catch (IOException ioe)
            {
                MessageBox.Show("Error: IO Exception caught" + ioe, "IO ERROR");
            }
            catch (Exception e)
            {
                MessageBox.Show("Exception caught" + e, "Exception Error");
            }
            //returns array of lines
            return lines;
        }
        /// <summary>
        /// Method: DisplayClassRoomData
        /// Purpose: Method created to return first 4 lines of external file
        /// Input: string[] classData
        /// Output: string[] details
        /// </summary>
        public static string[] DisplayClassRoomData(string[] classData)
        {
           //first line second value: teacher's name
            string[] teacher = classData[0].Split(',');
            string teacherName = teacher[1];
            //second line second value: classroom number
            string[] classroom = classData[1].Split(',');
            string classNumber = classroom[1];
            //third line second value: room number
            string[] room = classData[2].Split(',');
            string roomNumber = room[1];
            //forth line second value: date of saved file
            string[] date = classData[3].Split(',');
            string dateSaved = date[1];

            //string to return top values of file
            string[] details = { teacherName, classNumber, roomNumber, dateSaved};
            return details;
        }
        /// <summary>
        /// Method: getStudentList
        /// Purpose: Cretes list of student and their seats
        /// Input: string[] classData
        /// Output: List Student
        /// </summary>
        public static List<Student> getStudentList(string[] classData)
        {
            //new list of Student class
            List<Student> studentList = new List<Student>();
            //student data begins in the 5th line of external file
            for (int row = 4; row < classData.Count(); row++)
            {
                //split each line to get the stdents names and seats
                string[] cellValues = classData[row].Split(',');
                //if value is 'bkgrnd fill' it means it is just to fill the cells which is the place of desks, so we don't want to use these values
                if (!cellValues[2].Equals("BKGRND FILL") && !cellValues[2].Equals("Front Desk"))
                { 
                    //student name is placed in the third value of each line
                    string name = cellValues[2];
                    //col number is the first value of each line
                    int colNumber = Int32.Parse(cellValues[0]);
                    //row number is the second value of each line
                    int rowNumber = Int32.Parse(cellValues[1]);

                    //create new student and send to list with name, col and row values
                    Student student = new Student(name, colNumber, rowNumber);
                    studentList.Add(student);
                }
                else
                {
                    //if value is equal to bkgrnd fill I dont want to send it to my list
                }
            }
            return studentList;
        }
        /// <summary>
        /// Method: getStudentNameList
        /// Purpose: creates a list of students names
        /// Input: string[] classData
        /// Output: List string
        /// </summary>
        public static List<string> getStudentNameList(string[] classData)
        {
            //create new list of strings
            List<string> studentNameList = new List<string>();
            //gets all students name starting from 5th line
            for (int row = 4; row < classData.Count(); row++)
            {
                //split each line to get the 3rd value of each row to get student name only
                string[] cellValues = classData[row].Split(',');
                if (!cellValues[2].Equals("BKGRND FILL") && !cellValues[2].Equals("Front Desk"))
                {
                    string name = cellValues[2];
                    studentNameList.Add(name);
                }
                else
                {
                    //no action
                }
            }
            return studentNameList;
        }
        /// <summary>
        /// Method: saveFile
        /// Purpose: saves file with all data of classroom
        /// Input: string filepath, List Student  studentList, string teacher, string classRoom, string roomNumber
        /// Output: void
        /// </summary>
        public static void saveFile(string filepath, List<Student> studentList, string teacher, string classRoom, string roomNumber)
        {
            //validate teacher name(letters only)
            if (!ValidateString(teacher))
            {
                // string was not entered properly 
                MessageBox.Show("ERROR: Make sure teacher's name contains letters only");
            }
            else
            {
                string selectedFilePath = filepath;
                //string that will be populated with all data to be written to external file
                string outputTxt = "";
                outputTxt += "Teacher:," + teacher + "\n";
                outputTxt += "Class:," + classRoom + "\n";
                outputTxt += "Room:," + roomNumber + "\n";
                //current date is used
                outputTxt += "Date:," + DateTime.Now.ToString("d/M/yyyy") + "\n";
                //all lines that have a fixed value that cannot be changed
                outputTxt += "4,0,Front Desk\n3,1,BKGRND FILL, blue\n4,1,BKGRND FILL, blue\n5,1,BKGRND FILL, blue\n6,1,BKGRND FILL, blue\n1,4,BKGRND FILL, blue \n2,4,BKGRND FILL, blue \n4,4,BKGRND FILL, blue \n5,4,BKGRND FILL, blue \n7,4,BKGRND FILL, blue \n8,4,BKGRND FILL, blue \n";
                outputTxt += "1,7,BKGRND FILL,blue \n2,7,BKGRND FILL, blue \n4,7,BKGRND FILL, blue \n5,7,BKGRND FILL, blue \n7,7,BKGRND FILL, blue \n8,7,BKGRND FILL, blue \n";
                outputTxt += "1,10,BKGRND FILL,blue \n2,10,BKGRND FILL, blue \n4,10,BKGRND FILL, blue \n5,10,BKGRND FILL, blue \n7,10,BKGRND FILL, blue \n8,10,BKGRND FILL, blue \n";
                outputTxt += "1,13,BKGRND FILL,blue \n2,13,BKGRND FILL, blue \n4,13,BKGRND FILL, blue \n5,13,BKGRND FILL, blue \n7,13,BKGRND FILL, blue \n8,13,BKGRND FILL, blue \n1,16,BKGRND FILL, blue \n2,16,BKGRND FILL, blue \n4,16,BKGRND FILL, blue \n5,16,BKGRND FILL, blue \n7,16,BKGRND FILL, blue \n8,16,BKGRND FILL, blue \n";
               //all values of studentList 
                outputTxt += string.Join("", studentList);

                //write file
                File.WriteAllText(selectedFilePath, outputTxt);
                //show mesage that file has been saved
                MessageBox.Show("Data saved to " + selectedFilePath, "File Saved");
            }
        }
        /// <summary>
        /// Method: editCellValue
        /// Purpose: updates or create new student to the list which will be save later to the external file
        /// Input: string oldValue, string newValue, int col, int row, ListStudent  studentList, List string studentNameList
        /// Output: void
        /// </summary>
        public static void editCellValue(string oldValue, string newValue, int col, int row, List<Student> studentList, List<string> studentNameList)
        {
            //that is just an extra validation to ensure no wrong values are inserted in to the list (number or symbols)
            if (ValidateString(newValue))
            {
                //if cell is empty creates new student to the list
                if (String.IsNullOrEmpty(oldValue))
                {
                    Student newStudent = new Student(newValue, col, row);
                    studentList.Add(newStudent);

                    studentNameList.Add(newValue);
                }
                //else finds current student in the list and updates their name
                else
                {
                    int index = studentNameList.FindIndex(n => n == oldValue);
                    studentNameList[index] = newValue;


                    var student = studentList.FirstOrDefault(x => x.Name == oldValue);
                    student.Name = newValue;
                    student.ColNumber = student.ColNumber;
                    student.RowNumber = student.RowNumber;
                }
            }
            //message shows if wrong value was inputed
            else
            {
                MessageBox.Show("Invalid Input, please letters only", "ERROR: no symbols or number");
            }
        }
        /// <summary>
        /// Method: searchStudent
        /// Purpose: searches student in the list and displays list of students pointing student searched
        /// Input: List Student studentList, List string studentNameList , string find
        /// Output: void
        /// </summary>
        public static void searchStudent(List<Student> studentList, List<string> studentNameList , string find)
        {
            //sort both list first 
            studentList.Sort();
            studentNameList.Sort();
            //message to be displayed
            string message = "";

            string name;
            int colNumber;
            int rowNumber;
            //check if input is not empty
            if (String.IsNullOrEmpty(find))
            {
                MessageBox.Show("Enter a student name", "Empty Search");
            }
            else
            { 
                //gets index of student by its name in a binary search
                int foundIndex = BinarySearch(find, studentNameList);
                if (foundIndex >= 0)
                {
                    //get each student of list
                    foreach (Student item in studentList)
                    {
                        name = item.Name;
                        colNumber = item.ColNumber;
                        rowNumber = item.RowNumber;

                        //if name is equal of name searched a arrow will point to that name 
                        if (name.Equals(find))
                        {
                            message += name + "\t" + rowNumber + "\t" + colNumber + "\t<-FOUND \n";
                        }
                        else
                        {
                            message += name + "\t" + rowNumber + "\t" + colNumber + "\n";
                        }
                        
                    }
                    //display message
                    MessageBox.Show("Student\t Row\t Col\t \r\n" + message, "Student List - Search: " + find);
                }
                else
                {
                    MessageBox.Show("Sorry, no name for " + find, "Not Found");
                }
            }
        }
        /// <summary>
        /// Method: BinarySearch
        /// Purpose: binary search through list
        /// Input: string searchStr, List string strList
        /// Output: int foundIndex
        /// </summary>
        public static int BinarySearch(string searchStr, List<string> strList)
        {
            // found index
            // returns -1 if not found
            // returns 0 or more if found
            int foundIndex = -1;

            // min and max indexes
            int minNum = 0;
            int maxNum = strList.Count - 1;
            int midNum;
            bool foundStatus = false;

            // loop while minNum less than or equal to maxNum
            while (!foundStatus && minNum <= maxNum)
            {
                // get middle index
                midNum = (minNum + maxNum) / 2;
                // check if search str exists at index midNum
                if (searchStr.CompareTo(strList[midNum]) == 0)
                {
                    foundIndex = midNum;
                    foundStatus = true;
                    break;
                }
                else if (searchStr.CompareTo(strList[midNum]) < 0)
                {
                    maxNum = midNum - 1;
                }
                else if (searchStr.CompareTo(strList[midNum]) > 0)
                {
                    minNum = midNum + 1;
                }
            }

            return foundIndex;

        }
        /// <summary>
        /// Method: RAF_WriteToFile
        /// Purpose: Saves raf file with all classroom data
        /// Input: string value
        /// Output: bool
        /// </summary>
        public static void RAF_WriteToFile(List<Student> studentList, string teacher, string classRoom, string roomNumber)
        {
            // target file to write to
            string fileName = @"binaryData.dat";

            // data to write
            string outputTxt = "";
            outputTxt += "Teacher:," + teacher + "\n";
            outputTxt += "Class:," + classRoom + "\n";
            outputTxt += "Room:," + roomNumber + "\n";
            outputTxt += "Date:," + DateTime.Now.ToString("d/M/yyyy") + "\n";
            outputTxt += "4,0,Front Desk\n3,1,BKGRND FILL, blue\n4,1,BKGRND FILL, blue\n5,1,BKGRND FILL, blue\n6,1,BKGRND FILL, blue\n1,4,BKGRND FILL, blue \n2,4,BKGRND FILL, blue \n4,4,BKGRND FILL, blue \n5,4,BKGRND FILL, blue \n7,4,BKGRND FILL, blue \n8,4,BKGRND FILL, blue \n";
            outputTxt += "1,7,BKGRND FILL,blue \n2,7,BKGRND FILL, blue \n4,7,BKGRND FILL, blue \n5,7,BKGRND FILL, blue \n7,7,BKGRND FILL, blue \n8,7,BKGRND FILL, blue \n";
            outputTxt += "1,10,BKGRND FILL,blue \n2,10,BKGRND FILL, blue \n4,10,BKGRND FILL, blue \n5,10,BKGRND FILL, blue \n7,10,BKGRND FILL, blue \n8,10,BKGRND FILL, blue \n";
            outputTxt += "1,13,BKGRND FILL,blue \n2,13,BKGRND FILL, blue \n4,13,BKGRND FILL, blue \n5,13,BKGRND FILL, blue \n7,13,BKGRND FILL, blue \n8,13,BKGRND FILL, blue \n1,16,BKGRND FILL, blue \n2,16,BKGRND FILL, blue \n4,16,BKGRND FILL, blue \n5,16,BKGRND FILL, blue \n7,16,BKGRND FILL, blue \n8,16,BKGRND FILL, blue \n";

            // loop through studentList
            for (int i = 0; i < studentList.Count; i++)
            {
                outputTxt += studentList[i];
            }

            try
            {
                // FileStream object (sets up file stream with target file name usually in .bin or .dat format)
                // FileMode.Append means putting the stream in append mode (to write content which is added to any pre-existing content)
                // FileMode.Create means over-writing the existing content in the binary data file
                FileStream fstream = new FileStream(fileName, FileMode.Create, FileAccess.Write);
                //create a binary writer object
                BinaryWriter bwStream = new BinaryWriter(fstream);
                //set file position where to write data
                //fstream.Position = pos * size;
                //write data
                bwStream.Write(outputTxt);
                //close objects
                bwStream.Close();
                fstream.Close();
                // all done message
                MessageBox.Show("Classroom data successfully written to random access file" + fileName, "SUCCESS - Random File Access writen!");


            }
            catch (Exception e)
            {
                Console.WriteLine("ERROR: File writing problem!" + e);
            }
        }
        /// <summary>
        /// Method: ValidateString
        /// Purpose: Check if string has no symbols
        /// Input: string value
        /// Output: bool
        /// </summary>
        public static bool ValidateString(string value)
        { 
            //if string has numbers or symbols returs false
            if (!Regex.Match(value, "^[A-Z][a-zA-Z\\s]*$").Success || String.IsNullOrEmpty(value))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
