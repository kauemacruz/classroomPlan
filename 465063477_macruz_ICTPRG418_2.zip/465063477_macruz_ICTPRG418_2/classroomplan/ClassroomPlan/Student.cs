﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassroomPlan
{
    /// <summary>
    /// Class: Students : IComparable
    /// Purpose: Class created to manage list and compare values
    /// Input: void
    /// Output: void
    /// </summary>
    public class Student : IComparable<Student>
    {
        // private data properties 
        private string name;
        private int colNumber;
        private int rowNumber;

        //public data properties

        /// <summary>
        /// Method: Name
        /// Purpose: gets and returns value
        /// Input: void
        /// Output: void
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
 
        /// <summary>
        /// Method: colNumber
        /// Purpose: gets and returns value
        /// Input: void
        /// Output: void
        /// </summary>
        public int ColNumber
        {
            get { return colNumber; }
            set { colNumber = value; }
        }

        /// <summary>
        /// Method: rowNumber
        /// Purpose: gets and returns value
        /// Input: void
        /// Output: void
        /// </summary>
        public int RowNumber
        {
            get { return rowNumber; }
            set { rowNumber = value; }
        }

        //contructor method
        /// <summary>
        /// Method: Friend
        /// Purpose: gets values
        /// Input: void
        /// Output: void
        /// </summary>
        public Student(string name, int colNumber, int rowNumber)
        {
            Name = name;
            ColNumber = colNumber;
            RowNumber = rowNumber;
        }

        /// <summary>
        /// Method: CompareTo
        /// Purpose: compare values
        /// Input: void
        /// Output: void
        /// </summary>
        public int CompareTo(Student other)
        {
            //return 0 if names are identical
            //returns -1 if Name < other.Name
            // return 1 if Name > other.Name
            return Name.CompareTo(other.Name);
        }

        /// <summary>
        /// Method: ToString
        /// Purpose: converts values to string
        /// Input: void
        /// Output: void
        /// </summary>
        public override string ToString()
        {
            return ColNumber + "," + RowNumber + "," + Name + "\n";
        }
    }
}

