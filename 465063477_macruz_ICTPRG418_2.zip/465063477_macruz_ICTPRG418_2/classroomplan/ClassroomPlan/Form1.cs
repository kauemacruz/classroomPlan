﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClassroomPlan
{
    /// <summary>
    /// Class: Form1 : Form
    /// Purpose: main class of front end application
    /// </summary>
    public partial class Form1 : Form
    {
        //list of students
        private List<Student> studentList;
        //list of students names only
        private List<string> studentNameList;
        
        //number of rows to be used in grid
        static int TOTAL_ROWS = 18;
        // string array that will keep all data from external file 
        string[] classData;
        //string that will keep record of which file has been opened
        string filepath;
        //string that will keep record of initial value of cell before being edit
        string cellEditing;

        /// <summary>
        /// Method: Form1
        /// Purpose: main method
        /// Input: void
        /// Output: void
        /// </summary>
        public Form1()
        {
            InitializeComponent();

            //add further rows
            for (int i = 0; i < TOTAL_ROWS; i++)
            {
                dataGridView1.Rows.Add();
            }

            //set which cells can be edited
            dataGridView1.ReadOnly = false;
            dataGridView1.Columns[0].ReadOnly = true;
            dataGridView1.Columns[3].ReadOnly = true;
            dataGridView1.Columns[6].ReadOnly = true;
            dataGridView1.Columns[9].ReadOnly = true;
            dataGridView1.Rows[0].ReadOnly = true;
            dataGridView1.Rows[1].ReadOnly = true;
            dataGridView1.Rows[2].ReadOnly = true;
            dataGridView1.Rows[3].ReadOnly = true;
            dataGridView1.Rows[4].ReadOnly = true;
            dataGridView1.Rows[6].ReadOnly = true;
            dataGridView1.Rows[7].ReadOnly = true;
            dataGridView1.Rows[9].ReadOnly = true;
            dataGridView1.Rows[10].ReadOnly = true;
            dataGridView1.Rows[12].ReadOnly = true;
            dataGridView1.Rows[13].ReadOnly = true;
            dataGridView1.Rows[15].ReadOnly = true;
            dataGridView1.Rows[16].ReadOnly = true;
            dataGridView1.Rows[18].ReadOnly = true;
        }
        /// <summary>
        /// Method: openToolStripMenuItem_Click
        /// Purpose: Opens external files and populates grid and some fields
        /// Input: void
        /// Output: void
        /// </summary>
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "c:\\";
            openFileDialog.Filter = "txt files (=.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog.FilterIndex = 2;
            openFileDialog.RestoreDirectory = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                //enable access to buttons and cells to be edited
                dataGridView1.Enabled = true;
                clearChairs();
                search_textBox.Enabled = true;
                exitToolStripMenuItem.Enabled = true;
                clear_button.Enabled = true;
                saveChanges_button.Enabled = true;
                sort_button.Enabled = true;
                find_button.Enabled = true;
                saveRAF_button.Enabled = true;
                exit_button.Enabled = true;

                //get path
                filepath = openFileDialog.FileName;
                
                //set string array with class information
                classData = Methods.GetData(filepath);
                
                //give a number to each row
                for (int i = 0; i < TOTAL_ROWS; i++)
                {
                    dataGridView1.Rows[i].HeaderCell.Value = (i).ToString();
                }
                //string array that will hold the details to fill text box fields
                string[] details;
                //display external data in the datagridview
                details = Methods.DisplayClassRoomData(classData);
                teacher_textBox.Text = details[0];
                class_textBox.Text = details[1];
                room_textBox.Text = details[2];
                date_textBox.Text = details[3];

                //call method that will display values in grid
                DisplayCellsData();
                //get lists values
                studentList = Methods.getStudentList(classData);
                studentNameList = Methods.getStudentNameList(classData);
            }
        }
        /// <summary>
        /// Method: DisplayCellsData
        /// Purpose: displays data in specific cells
        /// Input: void
        /// Output: void
        /// </summary>
        private void DisplayCellsData()
        {
            //start reading from 5th value of array
            for (int row = 4; row < classData.Count(); row++)
            {
                //split each row to get first value of line(column), second value(row) and third value (student name)
                string[] cellValues = classData[row].Split(',');
                //if third value equals bkrgnd fill it means its just to color up cells in blue, else sets cell value with student name
                if (!cellValues[2].Equals("BKGRND FILL"))
                {
                    dataGridView1[Int32.Parse(cellValues[0]), Int32.Parse(cellValues[1])].Value = cellValues[2];
                }
                else
                {
                    dataGridView1[Int32.Parse(cellValues[0]), Int32.Parse(cellValues[1])].Style.BackColor = Color.Blue;
                }
            }
        }
        /// <summary>
        /// Method: saveToolStripMenuItem_Click
        /// Purpose: saves file in the same path it was opened
        /// Input: void
        /// Output: void
        /// </summary>
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(filepath)){
                MessageBox.Show("No file selected");
            }
            else
            {
                string teacher = teacher_textBox.Text;
                string classRoom = class_textBox.Text;
                string roomNumber = room_textBox.Text;
                Methods.saveFile(filepath, studentList, teacher, classRoom, roomNumber);
            }
        }
        /// <summary>
        /// Method: saveAsToolStripMenuItem_Click
        /// Purpose: saves file in chosen path
        /// Input: void
        /// Output: void
        /// </summary>
        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (String.IsNullOrEmpty(filepath))
            {
                MessageBox.Show("No file selected");
            }
            else
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.InitialDirectory = "c:\\";
                saveFileDialog.Filter = "txt files (=.txt)|*.txt|All files (*.*)|*.*";
                saveFileDialog.FilterIndex = 2;
                saveFileDialog.RestoreDirectory = true;

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string selectedFilePath = saveFileDialog.FileName;
                    string teacher = teacher_textBox.Text;
                    string classRoom = class_textBox.Text;
                    string roomNumber = room_textBox.Text;
                    Methods.saveFile(selectedFilePath, studentList, teacher, classRoom, roomNumber);
                }
            }
        }
        /// <summary>
        /// Method: saveChanges_button_Click
        /// Purpose: saves file in the same path it was opened
        /// Input: void
        /// Output: void
        /// </summary>
        private void saveChanges_button_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(filepath))
            {
                MessageBox.Show("No file selected");
            }
            else
            {
                string teacher = teacher_textBox.Text;
                string classRoom = class_textBox.Text;
                string roomNumber = room_textBox.Text;
                Methods.saveFile(filepath, studentList, teacher, classRoom, roomNumber);
            }
        }
        /// <summary>
        /// Method: dataGridView1_CellValidating
        /// Purpose: sets string value for cellEditing (value of cell before updating it)
        /// Input: void
        /// Output: void
        /// </summary>
        private void dataGridView1_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            cellEditing = (string)dataGridView1[e.ColumnIndex, e.RowIndex].Value;
        }
        /// <summary>
        /// Method: clear_button_Click
        /// Purpose: clears specific cells and lists
        /// Input: void
        /// Output: void
        /// </summary>
        private void clear_button_Click(object sender, EventArgs e)
        {
            clearChairs();
            studentList.Clear();
            studentNameList.Clear();
        }
        /// <summary>
        /// Method: clearChairs
        /// Purpose: clears specific cells
        /// Input: void
        /// Output: void
        /// </summary>
        private void clearChairs()
        {
            for (int row = 4; row < dataGridView1.Rows.Count; row++)
            {
                dataGridView1[1, row].Value = null;
                dataGridView1[2, row].Value = null;
                dataGridView1[4, row].Value = null;
                dataGridView1[5, row].Value = null;
                dataGridView1[7, row].Value = null;
                dataGridView1[8, row].Value = null;
            }
        }
        /// <summary>
        /// Method: sort_button_Click
        /// Purpose: sort lists by name
        /// Input: void
        /// Output: void
        /// </summary>
        private void sort_button_Click(object sender, EventArgs e)
        {
            studentNameList.Sort();
            studentList.Sort();
            MessageBox.Show("Student List alphabetically sorted!", "Student List Sorted");
        }
        /// <summary>
        /// Method: find_button_Click
        /// Purpose: finds student by name
        /// Input: void
        /// Output: void
        /// </summary>
        private void find_button_Click(object sender, EventArgs e)
        {
            string find = search_textBox.Text;

            Methods.searchStudent(studentList, studentNameList, find);

            search_textBox.Text = "";
        }
        /// <summary>
        /// Method: saveRAF_button_Click
        /// Purpose: saves raf file
        /// Input: void
        /// Output: void
        /// </summary>
        private void saveRAF_button_Click(object sender, EventArgs e)
        {
            string teacher = teacher_textBox.Text;
            string classRoom = class_textBox.Text;
            string roomNumber = room_textBox.Text;

            Methods.RAF_WriteToFile(studentList, teacher, classRoom, roomNumber);
        }
        /// <summary>
        /// Method: exit_button_Click
        /// Purpose: exits and saves data in current file
        /// Input: void
        /// Output: void
        /// </summary>
        private void exit_button_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to exit?";
            const string caption = "EXIT";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                string teacher = teacher_textBox.Text;
                string classRoom = class_textBox.Text;
                string roomNumber = room_textBox.Text;
                Methods.saveFile(filepath, studentList, teacher, classRoom, roomNumber);
                Application.Exit();
            }
            else if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
        /// <summary>
        /// Method: xitToolStripMenuItem_Click
        /// Purpose: exits and saves data in current file
        /// Input: void
        /// Output: void
        /// </summary>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to exit?";
            const string caption = "EXIT";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                string teacher = teacher_textBox.Text;
                string classRoom = class_textBox.Text;
                string roomNumber = room_textBox.Text;
                Methods.saveFile(filepath, studentList, teacher, classRoom, roomNumber);
                Application.Exit();
            }
            else if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
        /// <summary>
        /// Method: xitToolStripMenuItem_Click
        /// Purpose: exits and saves data in current file
        /// Input: void
        /// Output: void
        /// </summary>
        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            int RowIndex = e.RowIndex;
            int columnIndex = e.ColumnIndex;
            bool validation = true;

            string DataToValidate = dataGridView1.Rows[RowIndex].Cells[columnIndex].Value.ToString();
            foreach (char c in DataToValidate)
            {
                if (!char.IsLetter(c))
                {
                    validation = false;
                    break;
                }
            }

            if (validation == false)
            {
                MessageBox.Show("You can only enter letters", "Letters Only");

                dataGridView1.Rows[RowIndex].Cells[columnIndex].Value = cellEditing;
            }
            else
            {
                string newValue = (string)dataGridView1.Rows[RowIndex].Cells[columnIndex].Value;

                Methods.editCellValue(cellEditing, newValue, e.ColumnIndex, e.RowIndex, studentList, studentNameList);
            }

        }
    }
}
